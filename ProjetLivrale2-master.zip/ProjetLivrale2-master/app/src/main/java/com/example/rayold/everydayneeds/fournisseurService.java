package com.example.rayold.everydayneeds;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class fournisseurService extends AppCompatActivity {

    private static final String TAG = "fournisseurService";
    private TextView theDate;

    private Button buttonGoCalendar;
    private Button buttonSaveDate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fournisseur_service);
        theDate = (TextView) findViewById(R.id.date);
        buttonGoCalendar = (Button) findViewById(R.id.buttonGoCalendar);
        buttonSaveDate = (Button) findViewById(R.id.buttonSaveDate);

        Intent incomingIntent = getIntent();
        String date = incomingIntent.getStringExtra("date");
        theDate.setText(date);

        buttonGoCalendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(fournisseurService.this, CalendarAct.class);
                startActivity(intent);
            }
        });
    }


}
